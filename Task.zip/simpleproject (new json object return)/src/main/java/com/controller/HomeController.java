package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.entity.Details;

@Controller
public class HomeController {
	
	@Autowired
	HibernateTemplate ht; //calling hibernate template here only not making any dao 
	
	@RequestMapping(value = "/save" ,method = RequestMethod.POST)
	@Transactional
	public String addDetails(HttpServletRequest req,HttpServletResponse res)
	{
		
		String name=req.getParameter("name");
		int age=Integer.parseInt(req.getParameter("age"));
		
		Details d=new Details();
		d.setName(name);
		d.setAge(age);
		
		ht.save(d);
		
		return "fetch";
	}
	
	@RequestMapping(value = "/fetch" ,method = RequestMethod.GET)
	@ResponseBody
	public   ArrayList<Details> fetchDeatils(HttpServletRequest req)
	{
	   
		ArrayList<Details> details=(ArrayList<Details>) ht.loadAll(Details.class);
		System.out.println(details+" count "+details.size());
		return  details;
	}

}
