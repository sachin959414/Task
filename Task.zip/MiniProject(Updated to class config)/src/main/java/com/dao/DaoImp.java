package com.dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.entities.Comments;
import com.entities.Likes;
import com.entities.Posts;
import com.entities.RegisterDetails;

@Repository
@EnableTransactionManagement
public class DaoImp implements Dao {

	@Autowired
	HibernateTemplate ht;

	@Override
	@Transactional
	public void save(RegisterDetails user) {
		ht.save(user);
	}

	@Override
	public ArrayList<RegisterDetails> checkforloginUser(String username, String usertype) {

		System.out.println("hereeeee");
		Session s = ht.getSessionFactory().openSession();

		ArrayList<RegisterDetails> user = (ArrayList<RegisterDetails>) s
				.createNativeQuery("select * from registerdetails where UserName=? and usertype=? ",
						RegisterDetails.class)
				.setString(1, username).setString(2, usertype).list();

		System.out.println(user);
		return user;
	}

	@Override
	@Transactional
	public int userNameValidate(String username) {

		System.out.println("check 4");
		RegisterDetails user = ht.getSessionFactory().openSession().find(RegisterDetails.class, username);

		System.out.println(user);
		if (user == null) {
			return 1;
		}

		return 0;
	}

	@Override
	@Transactional
	public void savePost(Posts post) {
		ht.save(post);
	}

	@Override
	@Transactional
	public RegisterDetails find(String username) {

		return ht.get(RegisterDetails.class, username);
	}

	@Override
	@Transactional
	public ArrayList<Posts> findAllPosts() {

		ArrayList<Posts> posts = (ArrayList<Posts>) ht.loadAll(Posts.class);

		return posts;
	}

	@Override
	@Transactional
	public Posts findPost(int postid) {

		return ht.get(Posts.class, postid);

	}

	@Override
	@Transactional
	public ArrayList<Comments> postComments(int postId) {

		ArrayList<Comments> comments = (ArrayList<Comments>) ht.getSessionFactory().openSession()
				.createNativeQuery("select * from comments where postid_postId=?", Comments.class).setInteger(1, postId)
				.list();

		return comments;
	}

	@Override
	@Transactional
	public void saveComment(Comments com) {

		ht.save(com);

	}

	@Override
	public ArrayList<Likes> postLikes(int postid) {

		ArrayList<Likes> likes = (ArrayList<Likes>) ht.getSessionFactory().openSession()
				.createNativeQuery("select * from likes where post_postId=?", Likes.class).setInteger(1, postid).list();

		return likes;
	}

	@Override
	@Transactional
	public void deletePost(Posts post) {

		System.out.println(post);

		ht.delete(post);

	}

	@Override
	@Transactional
	public ArrayList<RegisterDetails> allusers() {

		ArrayList<RegisterDetails> users = (ArrayList<RegisterDetails>) ht.loadAll(RegisterDetails.class);

		return users;
	}
	
@Override
@Transactional
public void deleteUser(RegisterDetails user) {
	
	ht.delete(user);
}

@Override
@Transactional
public void saveLike(Likes like) {
	
	ht.save(like);
}

}
