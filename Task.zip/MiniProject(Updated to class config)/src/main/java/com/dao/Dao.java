package com.dao;

import java.util.ArrayList;

import com.entities.Comments;
import com.entities.Likes;
import com.entities.Posts;
import com.entities.RegisterDetails;

public interface Dao {
	
	public void save(RegisterDetails user);
	
	public ArrayList<RegisterDetails> checkforloginUser(String username,String usertype);
	
	public int userNameValidate(String username);
	
	public void savePost(Posts post);
	
	public RegisterDetails find(String username);
	
	public ArrayList<Posts> findAllPosts();
	
	public Posts findPost(int postid);
	
	public ArrayList<Comments> postComments(int postId);
	
	public void saveComment(Comments com);
	
	public void deletePost(Posts post);
	
	public ArrayList<Likes> postLikes(int postid);
	
	public ArrayList<RegisterDetails> allusers();
	
	public void deleteUser(RegisterDetails user);

	public void saveLike(Likes like);
}
