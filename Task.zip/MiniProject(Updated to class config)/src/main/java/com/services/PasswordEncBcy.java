package com.services;


import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

@Service
public class PasswordEncBcy {

	public String hashPassword(String textpassword)
	{	
		return BCrypt.hashpw(textpassword, BCrypt.gensalt());
	}
	
	public int checkPass(String plainPassword,String hashedPassword)
	{
		if(BCrypt.checkpw(plainPassword, hashedPassword))
		{
			return 1;
		}
		
	
		return 0;
	}
	
}
