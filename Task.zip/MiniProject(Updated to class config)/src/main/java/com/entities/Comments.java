package com.entities;

import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Comments {
	
	@Id
	private int commentid;
	
	
	@ManyToOne
	private Posts postid;
	
	
	@ManyToOne
	private RegisterDetails user;
	
	private String commentcontent;


	public int getCommentid() {
		return commentid;
	}


	public void setCommentid() {
		this.commentid =new Random().nextInt(100);
	}


	public Posts getPostid() {
		return postid;
	}


	public void setPostid(Posts postid) {
		this.postid = postid;
	}


	public String getCommentcontent() {
		return commentcontent;
	}


	public void setCommentcontent(String commentcontent) {
		this.commentcontent = commentcontent;
	}


	public RegisterDetails getUser() {
		return user;
	}


	public void setUser(RegisterDetails user) {
		this.user = user;
	}




	@Override
	public String toString() {
		return "Comments [commentid=" + commentid + ", postid=" + postid + ", commentcontent=" + commentcontent + "]";
	} 
	
	
	

}
