package com.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.sun.org.apache.bcel.internal.generic.LSTORE;

@Entity
public class RegisterDetails {
	
	
	private String name;
	
	private String email;
	
	private String contact;
	
	@Id
	private String UserName;
	
	private String password;
	
	private String usertype;

	private String Date;
	
	@OneToMany(mappedBy = "username",orphanRemoval = true,cascade = CascadeType.REMOVE,fetch = FetchType.LAZY)
	private List<Posts> posts;
	
	@OneToMany(mappedBy = "username",orphanRemoval = true,cascade = CascadeType.REMOVE,fetch = FetchType.LAZY)
	private List<Likes> like;
	
	@OneToMany(mappedBy = "user",orphanRemoval = true,cascade = CascadeType.REMOVE,fetch = FetchType.LAZY)
	private List<Comments> comments;
	
	public List<Posts> getPosts() {
		return posts;
	}
	public void setPosts(List<Posts> posts) {
		this.posts = posts;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	
	
	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	@Override
	public String toString() {
		return "RegisterDetails [name=" + name + ", email=" + email + ", contact=" + contact + ", UserName=" + UserName
				+ ", password=" + password + ", usertype=" + usertype + ", Date=" + Date + "]";
	}

	
	
	
	

}
