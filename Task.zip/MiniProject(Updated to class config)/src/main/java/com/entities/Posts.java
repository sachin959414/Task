package com.entities;

import java.util.*;
import java.util.Random;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Posts {
	
	@Id
	private int postId;
	
	@ManyToOne
	private RegisterDetails username;
	
	@OneToMany(mappedBy = "post",orphanRemoval = true,cascade = CascadeType.REMOVE)
	private List<Likes> likes;
	
	@OneToMany(mappedBy ="postid", orphanRemoval = true,cascade = CascadeType.REMOVE , fetch = FetchType.EAGER)
	private List<Comments> comments;
	
	
	private String content;
	
	private String Date;

	public int getPostId() {
		return postId;
	}

	public void setPostId() {
		this.postId = new Random().nextInt(1000);
	}

	public RegisterDetails getUsername() {
		return username;
	}

	public void setUsername(RegisterDetails username) {
		this.username = username;
	}
	
	
	

	public List<Likes> getLikes() {
		return likes;
	}

	public void setLikes(List<Likes> likes) {
		this.likes = likes;
	}

	public List<Comments> getComments() {
		return comments;
	}

	public void setComments(List<Comments> comments) {
		this.comments = comments;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	@Override
	public String toString() {
		return "Posts [postId=" + postId + ", username=" + username + ", content=" + content + ", Date=" + Date + "]";
	}
	
	
	

}
