package com.config;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import com.entities.Comments;
import com.entities.Likes;
import com.entities.Posts;
import com.entities.RegisterDetails;

@Configuration
public class HibernateConfig {

	
	@Bean(name = "datasource")
	public DriverManagerDataSource getDataSource()
	{
		DriverManagerDataSource data=new DriverManagerDataSource();
		data.setUrl("jdbc:mysql://localhost:3306/miniproject");
		data.setDriverClassName("com.mysql.cj.jdbc.Driver");
		data.setUsername("root");
		data.setPassword("admin");
		return data;
	}
	
	@Bean
	public LocalSessionFactoryBean getSessionFactory()
	{
		LocalSessionFactoryBean lsf=new LocalSessionFactoryBean();
		lsf.setDataSource(getDataSource());
	    Properties p=new Properties();
	    p.setProperty("hibernate.dialect","org.hibernate.dialect.MySQL8Dialect");
	    p.setProperty("hibernate.show_sql", "true");
	    p.setProperty("hibernate.hbm2ddl.auto", "update");
	    lsf.setHibernateProperties(p);
	    
	    lsf.setAnnotatedClasses(RegisterDetails.class,Posts.class,Likes.class,Comments.class);
	    
		return  lsf;
	}
	
	@Bean
	public HibernateTemplate getHibernateTemplate()
	{
		HibernateTemplate ht=new HibernateTemplate();
		ht.setSessionFactory(getSessionFactory().getObject());
		
		return ht;
	}
	
	@Bean
	public HibernateTransactionManager getTransaction()
	{
		HibernateTransactionManager htm=new HibernateTransactionManager();
		htm.setSessionFactory(getSessionFactory().getObject());
		return htm;
	}
	
}
